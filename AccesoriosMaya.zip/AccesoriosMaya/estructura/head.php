<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accesorios Maya</title>
    <link rel="stylesheet" href="/AccesoriosMaya/css/styles.css">
    <link rel="stylesheet" href="/AccesoriosMaya/css/carrusel.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Quicksand:wght@400;600;700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/AccesoriosMaya/css/banner-carousel.css">
</head>
<body>